import { TestBed } from '@angular/core/testing';

import { MiscBillingInvoiceEvaluationService } from './misc-billing-invoice-evaluation.service';

describe('MiscBillingInvoiceEvaluationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MiscBillingInvoiceEvaluationService = TestBed.get(MiscBillingInvoiceEvaluationService);
    expect(service).toBeTruthy();
  });
});
