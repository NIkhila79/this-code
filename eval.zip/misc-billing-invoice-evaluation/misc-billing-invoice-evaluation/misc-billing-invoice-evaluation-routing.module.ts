import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MiscBillingInvoiceEvaluationComponent } from './misc-billing-invoice-evaluation.component';

const routes: Routes = [
  {path : '' , component : MiscBillingInvoiceEvaluationComponent}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MiscBillingInvoiceEvaluationRoutingModule { }
