import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { environment } from '../../../../../environments/environment';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json'
})
}

@Injectable({
  providedIn: 'root'
})
export class MiscBillingInvoiceEvaluationService {
  apiUrl = environment.apiUrlMiscBilling;
  apiUrlMaster = environment.apiUrlMaster;
  globalUrl = environment.apiUrlGlobal;
  constructor(private commonService: CommonService,private http: HttpClient) { }

  searchformCode(data) { 
    return this.http.get(this.apiUrl+'misc-billing-invoice-evaluation/search-invoice',{params:this.commonService.SearchParams(this.commonService.convertApiObjMisc(data))}).pipe(
        tap(_ => this.commonService.log('fetched Invoices')),
        catchError(this.commonService.handleError('getSearchedInvoice', []))
      );
  }

  getInvoiceDetails(data){
    return this.http.get(this.apiUrl+'miscbilling-dashboard/invoiceDetails',{params:this.commonService.SearchParams(data)}).pipe(
      tap(_ => this.commonService.log('fetched Invoice Details')),
      catchError(this.commonService.handleError('getAllInvoiceDetails', []))
    );
  }

  getInvoiceDetailsOnInvoiceNo(data){
    return this.http.get(this.apiUrl+'misc-billing-invoice-evaluation/line-item-list',{params:this.commonService.SearchParams(data)}).pipe(
      tap(_ => this.commonService.log('fetched Invoice Details')),
      catchError(this.commonService.handleError('getAllInvoiceDetails', []))
    );
  }
  

  evaluateInvoice(data: any) {
    return this.http.put(this.apiUrl+'misc-billing-invoice/updateInvoiceStatus/INVOICE', data, httpOptions).pipe(
      tap(_ => this.commonService.log('fetched Invoice Search Details')),
      catchError(this.commonService.handleError('getInvoiceSearchDetails', []))
    );
  }


evaluateInvoiceLineItem(data: any) {
  return this.http.put(this.apiUrl+'misc-billing-invoice/updateInvoiceStatus/LINEITEM', data, httpOptions).pipe(
    tap(_ => this.commonService.log('fetched Invoice Search Details')),
    catchError(this.commonService.handleError('getInvoiceSearchDetails', []))
  );
}

createRejectedInvoice(){
  return this.http.post(this.apiUrl+'misc-billing-invoice/create-rejected-invoice',{},httpOptions).pipe(
    tap(_ => this.commonService.log('created rejected invoice')),
    catchError(this.commonService.handleError('createrejectedinvoice', []))
  );
}
saveOnLineItem(data: any){
  return this.http.put(this.apiUrl+'misc-billing-invoice-evaluation/lineItemUpdate/'+data.invLineItemId, data, httpOptions).pipe(
    tap(_ => this.commonService.log('fetched Invoice Search Details')),
    catchError(this.commonService.handleError('getInvoiceSearchDetails', []))
  );
}


getRejectionReasonCode(){
  return this.http.get(this.globalUrl +'rejectionReasonCode').pipe(
    tap(_ => this.commonService.log('fetched Invoice Search Details')),
    catchError(this.commonService.handleError('getInvoiceSearchDetails', []))
  );
}
}