import { MiscBillingInvoiceEvaluationModule } from './misc-billing-invoice-evaluation.module';

describe('MiscBillingInvoiceEvaluationModule', () => {
  let miscBillingInvoiceEvaluationModule: MiscBillingInvoiceEvaluationModule;

  beforeEach(() => {
    miscBillingInvoiceEvaluationModule = new MiscBillingInvoiceEvaluationModule();
  });

  it('should create an instance', () => {
    expect(miscBillingInvoiceEvaluationModule).toBeTruthy();
  });
});
