import { Component, OnInit, Input,EventEmitter ,Output ,ViewChild,ElementRef} from '@angular/core';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { LovService } from 'src/app/modules/masters/services/LOV/lov.service';
import * as _ from 'underscore';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ChargeCode } from 'src/app/modules/masters/models/interline/charge-code';
import { MiscBillingInvoiceEvaluationService } from '../misc-billing-invoice-evaluation.service';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { DISABLED } from '@angular/forms/src/model';
import { MessageBoxService } from 'src/app/modules/masters/services/commons/message-box.service';
import { AlertMessageConstants } from 'src/app/commons/properties/alert-message-constants.properties';
import { InvoiceCaptureScreenConstants } from '../../constants/misc-billing-constants';
import { InvoiceCaptureService } from '../../invoice-capture/services/invoice-capture.service';
import { DateConstant } from 'src/app/commons/properties/date-constant.properties';
@Component({
  selector: 'app-invoice-evaluation-line-item',
  templateUrl: './invoice-evaluation-line-item.component.html',
  styleUrls: ['./invoice-evaluation-line-item.component.css']
})
export class InvoiceEvaluationLineItemComponent implements OnInit {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
	@ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  showInvoiceLineItem :boolean;
  @Input() invoiceDetailsData:any;
  @Output() selectedRowDataLineItem = new EventEmitter();
  @Output() setAlertMessage = new EventEmitter();
  taxDetailsList1 :any = [];
  vatDetailsList1 :any = [];
  addOnDetailsList1 :any = [];
  taxDetailsList :any = [];
  grandTotalTax:any;
  grandTotalVat:any;
  taxDetailsLineItem:any
  grandTotalAddOn:any;
  showTaxDetails :boolean;
  showVatDetails :boolean;
  showAddOnDetails :boolean;
  currentIndex : number;
  vatDetailsList :any = [];
  addOnDetailsList :any = [];
  chargeCodeList: ChargeCode[];
  submitted:boolean;
  clientID : String = "";
  editIcon :boolean;
  lineItemForm :FormGroup;
  showTaxDetailOnForm:boolean;
  showVatDetailOnForm:boolean;
  showAddOnDetailOnForm:boolean;
  taxAtLineItem:any;
  vatAtLineItem:any;
  addOnAtLineItem:any;
  addOnDetailsLineItem:any
  vatDetailsLineItem:any;
  rejectionCodeArray:any
  // @Output() selectedRowDataLineItem = new EventEmitter();
  page:any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  level:any;

 acceptedAmount:any;
 taxAmount:any;
taxPercentage:any;
  @ViewChild('sortTable') sortTable: DatatableComponent;
  currentSort:any = [{ prop: "", dir: 'asc'}];
  group1 =[{"name":"Charge Amount","key":"chargeAmount"}, 
  {"name":"Tax Amount","key":"totalTaxAmount"},
  {"name":"VAT Amount","key":"totalVatAmount"},
  {"name":"Addon Charges","key":"totalAddonChargeAmount"},
  {"name":"Total Amount","key":"totalNetAmount"}];
  group2 =[{"name":"Charge Amount","key":"chargeAmountAccepted"},
  {"name":"Tax Amount","key":"totalTaxAmountAccepted"},
  {"name":"VAT Amount","key":"totalVatAmountAccepted"},
  {"name":"Addon Charges","key":"totAddonChargeAmtAccepted"},
  {"name":"Total Amount","key":"netAmountAccepted"}];
  group3 =[{"name":"Charge Amount","key":"chargeAmountRejected"},
  {"name":"Tax Amount","key":"totalTaxAmountRejected"},
  {"name":"VAT Amount","key":"totalVatAmountRejected"},
  {"name":"Addon Charges","key":"totAddonChargeAmtRejected"},
  {"name":"Total Amount","key":"netAmountRejected"}];
  success: any = {
		isSuccess: false,
		successMessage: ''
  };
  invoiceCaptureScreenConstants = InvoiceCaptureScreenConstants;
  currentLevel : string = this.invoiceCaptureScreenConstants.INVOICE_LEVEL;
  result: any;
  mandatorySign:boolean;
  DATE_FORMAT = DateConstant.DATE;
  showCaptureScreen: boolean;
  toMinDate:any;
	fromMaxDate:any;
  showEvaluationFields: boolean;
  constructor(private commonService: CommonService, private miscBillingInvoiceEvaluationService:MiscBillingInvoiceEvaluationService,private paginateService: PaginationService,public lov:LovService,
  public formBuilder:FormBuilder,private messageBoxService: MessageBoxService,private invoiceCaptureService:InvoiceCaptureService) { }

  ngOnInit() {
    this.lov.initLovDDS('misc_billing');
    this.lineItemForm = this.formBuilder.group({
      chargeCode:[''],
      clientId:[''],
      chargeCodeName:[''],
      locationCode: [''],
      startDate: [''],
      endDate: [''],
      chargeAmount: [''],
      totalTaxAmount: [''],
      totalVatAmount: [''],
      totalAddonChargeAmount: [''],
      totalNetAmount: [''],
      chargeAmountAccepted: [0,[this.compareAcceptedChargeAmtAndBilledAmt]],
      totalTaxAmountAccepted: [0],
      totalVatAmountAccepted: [0],
      totAddonChargeAmtAccepted: [0],
      netAmountAccepted: [0],
      chargeAmountRejected: [0],
      totalTaxAmountRejected: [0],
      totalVatAmountRejected: [0],
      totAddonChargeAmtRejected: [0],
      netAmountRejected: [0],
      rejectionReasonCode: [0],
      processStatus: [''],
      description: [''],
      reasonDescription:[''],
      invLineItemId:[],
      miscBillingTaxDetails:[[]],
      miscBillingAddOnChargeDtl:[[]]
    });
    this.getRejectedCode();
    this.getStartDate(this.lineItemForm,'startDate');
    this.getEndDate(this.lineItemForm,'endDate');
    this.getAddOnChargeDetailsForm();
  }
  get ef() { return this.lineItemForm.controls; }
  // showSelectedRow(data: any,level): void {
  //   this.selectedRowDataLineItem.emit({data, level});
  // }
  getAddOnChargeDetailsForm(){
    return this.formBuilder.group({
      addOnChargeAmount: [0,[Validators.required]],
      addOnChargeName: ['',[Validators.required]],
      addOnChargePercentage: [0],
      addOnChargeableAmount: [0],
      addOnLevel: [''],
      invoiceId: [],
      miscBillingAddOnChargeDtlId: [],
      recordSeqNumber: 1,
      addonChargeAccepted:[0],
    })
  }

  getTaxDetails(row:any){

    this.taxDetailsList1 = row.miscBillingTaxDetails.filter(taxDetails => {
      return taxDetails.taxType.toUpperCase() == "TAX";
    });
    this.grandTotalTax = this.taxDetailsList1.reduce((s, f) => s + f.taxAmount, 0);
    this.showCaptureScreen = false;
    this.showEvaluationFields = true;
    this.showTaxDetails = true;
    }
  getVatDetails(row:any){
      this.vatDetailsList1 = row.miscBillingTaxDetails.filter(vatDetails => {
        return vatDetails.taxType.toUpperCase() == "VAT";
      });
      this.grandTotalVat = this.vatDetailsList1.reduce((s, f) => s + f.taxAmount, 0);
      this.showCaptureScreen = false;
      this.showEvaluationFields = true;
      this.showVatDetails = true;
    } 
  getAddOnDetails(row:any){
    this.addOnDetailsList1 = row.miscBillingAddOnChargeDtl;
    this.grandTotalAddOn = this.addOnDetailsList1.reduce((s, f) => s + f.addOnChargeAmount, 0);
    this.showAddOnDetails = true;
    this.showCaptureScreen = false;
    this.showEvaluationFields = true;
    }
  
  getTaxDetailsForBilled(row){
    this.getTaxDetails(row);
    this.showEvaluationFields = false;
  }
  getVatDetailsForBilled(row){
    this.getVatDetails(row);
    this.showEvaluationFields = false
  }
  getAddOnDetailsForBilled(row){
    this.getAddOnDetails(row);
    this.showEvaluationFields = false
  }

  setAmountUptotwoDecimal(tempForm){
    tempForm.chargeAmount =  tempForm.chargeAmount == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.chargeAmount).toFixed(2);
    tempForm.totalTaxAmount =  tempForm.totalTaxAmount == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalTaxAmount).toFixed(2);
    tempForm.totalVatAmount =  tempForm.totalVatAmount == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalVatAmount).toFixed(2);
    tempForm.totalAddonChargeAmount =  tempForm.totalAddonChargeAmount == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalAddonChargeAmount).toFixed(2);
    tempForm.totalNetAmount =  tempForm.totalNetAmount == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalNetAmount).toFixed(2);
    tempForm.chargeAmountAccepted =  tempForm.chargeAmountAccepted == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.chargeAmountAccepted).toFixed(2);
    tempForm.totalTaxAmountAccepted =  tempForm.totalTaxAmountAccepted == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalTaxAmountAccepted).toFixed(2);
    tempForm.totalVatAmountAccepted =  tempForm.totalVatAmountAccepted == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalVatAmountAccepted).toFixed(2);
    tempForm.totAddonChargeAmtAccepted =  tempForm.totAddonChargeAmtAccepted == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totAddonChargeAmtAccepted).toFixed(2);
    tempForm.netAmountAccepted =  tempForm.netAmountAccepted == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.netAmountAccepted).toFixed(2);
    tempForm.chargeAmountRejected =  tempForm.chargeAmountRejected == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.chargeAmountRejected).toFixed(2);
    tempForm.totalTaxAmountRejected =  tempForm.totalTaxAmountRejected == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalTaxAmountRejected).toFixed(2);
    tempForm.totalVatAmountRejected =  tempForm.totalVatAmountRejected == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totalVatAmountRejected).toFixed(2);
    tempForm.totAddonChargeAmtRejected =  tempForm.totAddonChargeAmtRejected == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.totAddonChargeAmtRejected).toFixed(2);
    tempForm.netAmountRejected =  tempForm.netAmountRejected == null || 0?'0.00': this.invoiceCaptureService.stringToFloat(tempForm.netAmountRejected).toFixed(2);
  }  
  editLineItem(rowIndex, row){

    this.currentIndex = rowIndex;
    let tempForm =  JSON.parse(JSON.stringify(row));
    tempForm.startDate = new Date(tempForm.startDate);
    tempForm.endDate = new Date(tempForm.endDate);
    this.setAmountUptotwoDecimal(tempForm);
    this.result = tempForm;
    this.lineItemForm.patchValue(tempForm);
   
    console.log(this.lineItemForm);
    this.lineItemForm.get("processStatus").disable();
    this.setFormValidator();
    this.taxAtLineItem = row.miscBillingTaxDetails.filter(taxDetails => {
    return taxDetails.taxType.toUpperCase() == "TAX";
    });
    this.vatAtLineItem = row.miscBillingTaxDetails.filter(vatDetails => {
      return vatDetails.taxType.toUpperCase() == "VAT";
    });
    this.addOnAtLineItem = row.miscBillingAddOnChargeDtl.map(addOnDetails => {
      return addOnDetails;
    });
  }

  setFormValidator(){
    if(this.invoiceCaptureService.stringToFloat(this.lineItemForm.controls['netAmountRejected'].value)>=1){
      this.mandatorySign = true;
      this.lineItemForm.controls['rejectionReasonCode'].setValidators([Validators.required]);
      this.lineItemForm.controls['rejectionReasonCode'].updateValueAndValidity();
      this.lineItemForm.controls['description'].setValidators([Validators.required]);
      this.lineItemForm.controls['description'].updateValueAndValidity();
    }else{
      this.mandatorySign = false;
      //this.lineItemForm.controls['rejectionReasonCode'].setValue(null);
      this.lineItemForm.controls['rejectionReasonCode'].clearValidators();
      this.lineItemForm.controls['rejectionReasonCode'].updateValueAndValidity();
      //this.lineItemForm.controls['description'].setValue(null);
      this.lineItemForm.controls['description'].clearValidators();
      this.lineItemForm.controls['description'].updateValueAndValidity();
    }
  }

  getTaxDetailOnLineItemEdit(data){

    this.taxDetailsList1 = data.filter(taxDetails => {
      return taxDetails.taxType.toUpperCase() == "TAX";
    });
    this.grandTotalVat = this.taxDetailsList1.reduce((s, f) => s + f.taxAmount, 0);
    this.showCaptureScreen = true;
    this.showEvaluationFields = true;
    this.showTaxDetails = true;
  //   this.taxDetailsLineItem = data;
  //   this.taxDetailsLineItem = this.taxDetailsLineItem.map(taxDetails => {
  //     taxDetails.taxPercentage = 10;
  //     taxDetails.taxAmountAccepted = taxDetails.taxableAmount * taxDetails.taxPercentage/100
  //     this.grandTotalTax = this.taxDetailsLineItem.reduce((s, f) => s + f.taxAmountAccepted, 0);   
  //     return taxDetails;

  // })
  //   this.showCaptureScreen = true;
  //   this.showEvaluationFields =true;
  //   // this.showTaxDetailOnForm = true;
  //   this.showTaxDetails = true;
  }

  getVatDetailOnLineItemEdit(data){
    this.vatDetailsList1 = data.filter(vatDetails => {
      return vatDetails.taxType.toUpperCase() == "VAT";
    });
    this.grandTotalVat = this.vatDetailsList1.reduce((s, f) => s + f.taxAmount, 0);
    this.showCaptureScreen = true;
    this.showEvaluationFields = true;
    this.showVatDetails = true;

     
  //   this.vatDetailsLineItem = data;
  //   this.vatDetailsLineItem = this.vatDetailsLineItem.map(vatDetails => {
  //     vatDetails.taxPercentage = 10;
  //     vatDetails.vatAmountAccepted = vatDetails.taxableAmount * vatDetails.taxPercentage/100
  //     this.grandTotalVat = this.vatDetailsLineItem.reduce((s, f) => s + f.vatAmountAccepted, 0);   
  //     return vatDetails;

  // })
  //   this.showCaptureScreen = true;
  //   this.showEvaluationFields =true;
  //   // this.showVatDetailOnForm = true;
  //   this.showVatDetails = true;
  }

  getAddOnDetailOnLineItemEdit(data){
      this.addOnDetailsList1 = data;
      this.grandTotalAddOn = this.addOnDetailsList1.reduce((s, f) => s + f.addOnChargeAmount, 0);
      this.showAddOnDetails = true;
      this.showCaptureScreen = true;
      this.showEvaluationFields = true;
      


  //   this.addOnDetailsLineItem = data;
  //   this.addOnDetailsLineItem = this.addOnDetailsLineItem.map(addOnDetails => {
  //     addOnDetails.addonChargeAccepted = addOnDetails.addOnChargeableAmount * addOnDetails.addOnChargePercentage/100
  //     this.grandTotalAddOn = this.addOnDetailsLineItem.reduce((s, f) => s + f.addonChargeAccepted, 0);   
  //     return addOnDetails;

  // })
  //   this.showCaptureScreen = true;
  //   this.showEvaluationFields =true;
  //   // this.showAddOnDetailOnForm = true;
  //   this.showAddOnDetails = true;
  }

  onReset(): void {
    this.submitted=false;
    this.lineItemForm.reset();
   }
   focusOutFunction(event){
   var a = event.target.innerText;
   this.taxDetailsLineItem = this.taxDetailsLineItem.map(taxDetails => {
    taxDetails.taxableAmount = a;
    return taxDetails;
   })
   }
   closeAlertValidation() {
		let tempThis = this;
		window.setTimeout(() => {
			tempThis.success = {
				isSuccess: false,
				successMessage: ''
			};
		}, AlertMessageConstants.CLOSE_ALERT_TIME);
	}
   updateLineItem(){
		if (this.lineItemForm.invalid){
      this.submitted=true;
		}else{
      this.lineItemForm.get('processStatus').setValue('EV');
      const lineItem = Object.assign({}, this.lineItemForm.getRawValue());
      lineItem.startDate = this.commonService.splitDate(lineItem.startDate);
		  lineItem.endDate = this.commonService.splitDate(lineItem.endDate);
      lineItem.clientId = (lineItem.clientId).trim();
      this.miscBillingInvoiceEvaluationService.saveOnLineItem(lineItem).subscribe((res: any) => {
        if (res && res.invLineItemId) {
          this.selectedRowDataLineItem.emit(res);
          this.success = {
            isSuccess: true,
            successMessage: "Record has been successfully saved"
          };
          this.setAlertMessage.emit(this.success);
          this.closeModalEdit.nativeElement.click();
          this.closeAlertValidation();
        }
		});
	}
  }

  getRejectedCode(){
    this.miscBillingInvoiceEvaluationService.getRejectionReasonCode().subscribe((response:any) => {   
    this.rejectionCodeArray = response;
    })
  }
  onRejectionCodeChange(){
      this.lineItemForm.controls['reasonDescription'].setValue(this.rejectionCodeArray.find(rejectionCode => {
        return rejectionCode.rejectionReasonCode === this.lineItemForm.controls['rejectionReasonCode'].value
      }).description);
    
  }
  saveTaxVatDetails(data){
    const taxOrVat = data.taxOrVat;
    const taxVatDetails = data.taxVatDetailsList;
      this.result.miscBillingTaxDetails = this.invoiceCaptureService.concatTaxAndVat(this.result.miscBillingTaxDetails, taxOrVat, taxVatDetails);
      this.result.taxAmount = taxOrVat === this.invoiceCaptureScreenConstants.DEFAULT_TAX ? taxVatDetails.reduce((acc, value) => acc + value.taxAmount, 0) : this.result.taxAmount;
      // this.lineItemForm.controls['totalTaxAmountAccepted'].setValue(this.result.taxAmountAccepted);
      this.result.totalTaxAmountAccepted = this.result.taxAmount === 'TAX' ? this.result.miscBillingTaxDetails.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.taxAmountAccepted), 0): '0.00';
      this.result.totalTaxAmountRejected = this.result.taxAmount === 'TAX' ? this.result.miscBillingTaxDetails.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.taxAmountRejected), 0) : '0.00';
      this.result.vatAmount = taxOrVat === this.invoiceCaptureScreenConstants.DEFAULT_VAT ? taxVatDetails.reduce((acc, value) => acc + value.taxAmount, 0) : this.result.vatAmount;
      // this.lineItemForm.controls['totalVatAmountAccepted'].setValue(this.result.taxAmountAccepted);
      this.result.totalVatAmountAccepted = this.result.taxAmount === 'VAT' ? this.result.miscBillingTaxDetails.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.taxAmountAccepted), 0) : '0.00';
      this.result.totalVatAmountRejected = this.result.taxAmount === 'VAT' ? this.result.miscBillingTaxDetails.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.taxAmountRejected), 0): '0.00';
      this.lineItemForm.patchValue(this.result);
  }
  saveAddOnChargeDetails(data){
    const addOnChargeDetails = data.addOnChargeDetailsList;
    this.result.addonChargeAmount = addOnChargeDetails.reduce((acc, value) => acc + value.addOnChargeAmount, 0);
    this.result.totAddonChargeAmtAccepted = this.result.miscBillingAddOnChargeDtl.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.addonChargeAccepted), 0);
    this.result.totAddonChargeAmtRejected = this.result.miscBillingAddOnChargeDtl.reduce((acc,value) => acc + this.invoiceCaptureService.stringToFloat(value.addonChargeRejected), 0);
    this.result.miscBillingAddOnChargeDtl = addOnChargeDetails;
    this.lineItemForm.patchValue(this.result);
  }
  compareAcceptedChargeAmtAndBilledAmt(controls){
    if(controls.value!= undefined && controls.value != null && controls.value != ""){
      const acceptedChargeAmount = typeof controls.value =='string' ? parseFloat(controls.value) : controls.value;
      const chargeAmount = typeof controls.parent.controls['chargeAmount'].value =='string' ? parseFloat(controls.parent.controls['chargeAmount'].value) : controls.parent.controls['chargeAmount'].value;
      if(acceptedChargeAmount <= chargeAmount){
       return null;
      }else {
        return { 'compareAcceptedChargeAmtAndBilledAmt': true };
      }
  }
}
  isEmpty(val){
    // if(val != undefined){
    //   return parseInt(val);
    // }else if(val == null || val == '' ){
    //   return 0;
    // }else{
    //   return null;
    // }
    if(val == null || val == ''){
      return 0;
    }else{
      return parseInt(val);
    }
  } 
  
  getAcceptedRejectedTotalAmt(){
    var tempObj:any = [];
    if(this.lineItemForm.controls['chargeAmountAccepted'].value != undefined){
      tempObj.push(this.lineItemForm.controls['chargeAmountAccepted'].value == null ||this.lineItemForm.controls['chargeAmountAccepted'].value == '' ? '0.00' : this.lineItemForm.controls['chargeAmountAccepted'].value);
    }if(this.lineItemForm.controls['totalTaxAmountAccepted'].value != undefined){
      tempObj.push(this.lineItemForm.controls['totalTaxAmountAccepted'].value == null ||this.lineItemForm.controls['totalTaxAmountAccepted'].value == '' ? '0.00' : this.lineItemForm.controls['totalTaxAmountAccepted'].value);
    }if(this.lineItemForm.controls['totalVatAmountAccepted'].value != undefined){
      tempObj.push(this.lineItemForm.controls['totalVatAmountAccepted'].value == null ||this.lineItemForm.controls['totalVatAmountAccepted'].value == '' ? '0.00' : this.lineItemForm.controls['totalVatAmountAccepted'].value);
    }if(this.lineItemForm.controls['totAddonChargeAmtAccepted'].value != undefined){
      tempObj.push(this.lineItemForm.controls['totAddonChargeAmtAccepted'].value == null ||this.lineItemForm.controls['totAddonChargeAmtAccepted'].value == '' ? '0.00' : this.lineItemForm.controls['totAddonChargeAmtAccepted'].value);
    }
    var totalAmt = 0;
    for (let i= 0; i < tempObj.length; i++) {
      if(parseInt(tempObj[i])){
        totalAmt += parseInt(tempObj[i]);
      }
      this.lineItemForm.controls['netAmountAccepted'].setValue(totalAmt); 
    }
    let rejectedChargeAmt = this.isEmpty(this.lineItemForm.get('chargeAmount').value) - this.isEmpty(this.lineItemForm.get('chargeAmountAccepted').value);
    let rejectedTaxAmt = this.isEmpty(this.lineItemForm.get('totalTaxAmount').value) - this.isEmpty(this.lineItemForm.get('totalTaxAmountAccepted').value);
    let rejectedVatAmt = this.isEmpty(this.lineItemForm.get('totalVatAmount').value) - this.isEmpty(this.lineItemForm.get('totalVatAmountAccepted').value);
    let rejectedAddonAmt = this.isEmpty(this.lineItemForm.get('totalAddonChargeAmount').value) - this.isEmpty(this.lineItemForm.get('totAddonChargeAmtAccepted').value);
    let rejectedTotalAmt = this.isEmpty(this.lineItemForm.get('totalNetAmount').value) - this.isEmpty(this.lineItemForm.get('netAmountAccepted').value);
    this.lineItemForm.controls['chargeAmountRejected'].setValue(rejectedChargeAmt); 
    this.lineItemForm.controls['totalTaxAmountRejected'].setValue(rejectedTaxAmt); 
    this.lineItemForm.controls['totalVatAmountRejected'].setValue(rejectedVatAmt); 
    this.lineItemForm.controls['totAddonChargeAmtRejected'].setValue(rejectedAddonAmt); 
    this.lineItemForm.controls['netAmountRejected'].setValue(rejectedTotalAmt); 
    this.setFormValidator();
  }
  getStartDate(formName:any,obj:string){
		formName.controls[obj].valueChanges.subscribe((minDate) => {
			return this.toMinDate = minDate;
		});
	}
	getEndDate(formName:any,obj:string){
		formName.controls[obj].valueChanges.subscribe((maxDate) => {
			return this.fromMaxDate = maxDate;
		});
  }
  calculateAcceptedRejectedTotalAmt(){
    const data = this.lineItemForm.value;
    let acceptedChargeAmt = this.invoiceCaptureService.stringToFloat(data.chargeAmountAccepted);
    let acceptedTaxAmt = this.invoiceCaptureService.stringToFloat(data.totalTaxAmountAccepted);
    let acceptedVatAmt = this.invoiceCaptureService.stringToFloat(data.totalVatAmountAccepted);
    let acceptedAddonCharge = this.invoiceCaptureService.stringToFloat(data.totAddonChargeAmtAccepted);
    let lineItemAcceptedTotalAmt = (acceptedChargeAmt + acceptedTaxAmt + acceptedVatAmt + acceptedAddonCharge);
    data.netAmountAccepted = lineItemAcceptedTotalAmt; 

    data.chargeAmountRejected = this.invoiceCaptureService.stringToFloat(data.chargeAmount) - acceptedChargeAmt;
    data.totalTaxAmountRejected = this.invoiceCaptureService.stringToFloat(data.totalTaxAmount) - acceptedTaxAmt;
    data.totalVatAmountRejected = this.invoiceCaptureService.stringToFloat(data.totalVatAmount) - acceptedVatAmt;
    data.totAddonChargeAmtRejected = this.invoiceCaptureService.stringToFloat(data.totalAddonChargeAmount) -  acceptedAddonCharge;
    let lineItemRejectedTotalAmt = (this.invoiceCaptureService.stringToFloat(data.totalNetAmount) - this.invoiceCaptureService.stringToFloat(data.netAmountAccepted));
    data.netAmountRejected = lineItemRejectedTotalAmt
    this.lineItemForm.patchValue(data);
    this.setFormValidator();
  }

  chekAmout(val){
    if(val == null || val == 0){
      return 0.00
    }else if(val != null && typeof val === 'string'){
      let tempVal = parseFloat(val).toFixed(2);
      return parseFloat(tempVal);
    }else if (val != null && typeof val === 'number'){
      let tempVal = val.toFixed(2);
      return parseFloat(tempVal);
    }
  }
}
