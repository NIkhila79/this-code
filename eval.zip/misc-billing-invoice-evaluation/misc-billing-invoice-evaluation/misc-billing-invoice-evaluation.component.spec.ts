import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscBillingInvoiceEvaluationComponent } from './misc-billing-invoice-evaluation.component';

describe('MiscBillingInvoiceEvaluationComponent', () => {
  let component: MiscBillingInvoiceEvaluationComponent;
  let fixture: ComponentFixture<MiscBillingInvoiceEvaluationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiscBillingInvoiceEvaluationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscBillingInvoiceEvaluationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
