import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, PatternValidator } from '@angular/forms';
import { PaginationService } from '../../../../commons/services/pagination/pagination.service';
import { BsDatepickerConfig, BsDatepickerViewMode } from 'ngx-bootstrap/datepicker';
import { HttpClient } from '@angular/common/http';
import { CarrierMasterService } from 'src/app/modules/masters/services/others/carrier-master/carrier-master.service';
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { LovService } from 'src/app/modules/masters/services/LOV/lov.service';
import { Router, NavigationExtras } from '@angular/router';
import { DateConstant } from '../../../../commons/properties/date-constant.properties';
import { MiscBillingInvoiceEvaluationService } from './misc-billing-invoice-evaluation.service';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { ChargeCategoryService } from 'src/app/modules/masters/services/interline/charge-category/charge-category.service';
import { ChargeCategory } from 'src/app/modules/masters/models/interline/charge-category';
import { ChargeCode } from 'src/app/modules/masters/models/interline/charge-code';
import { ChargeCodeService } from 'src/app/modules/masters/services/interline/charge-code/charge-code.service';

import * as _ from 'underscore';
import { MessageBoxService } from 'src/app/modules/masters/services/commons/message-box.service';
import { rowList } from 'src/app/modules/rnd/ngx-multicolumn-table/ngx-multicolumn-table/data-list';
import { InvoiceCaptureScreenConstants } from '../constants/misc-billing-constants';
import { InvoiceCaptureHttpService } from '../invoice-capture/services/invoice-capture-http.service';
import { InvoiceEvaluationLineItemComponent } from './invoice-evaluation-line-item/invoice-evaluation-line-item.component';
import { AlertMessageConstants } from 'src/app/commons/properties/alert-message-constants.properties';
@Component({
  selector: 'app-misc-billing-invoice-evaluation',
  templateUrl: './misc-billing-invoice-evaluation.component.html',
  styleUrls: ['./misc-billing-invoice-evaluation.component.css']

})
export class MiscBillingInvoiceEvaluationComponent implements OnInit {
  @ViewChild(InvoiceEvaluationLineItemComponent) invoiceEvaluationLineItem: InvoiceEvaluationLineItemComponent;
  searchForm: FormGroup;
  invoiceSearchList:any = [];
  renderDT:boolean;
  // toggleSearch:boolean;
  advanceSearch:Boolean;
  invoiceDetails:boolean;
  invoiceNumberFormat : any;
  showInvoiceLineItem:boolean;
  confirmData:any;
  invoices:any=[];
  selectedAll:boolean;
  invoiceStatus:any;
  toggleSearchSection:boolean;
  level :any;
  STATUS_CONFIRMED = "Confirmed"
  selectedRowData:any;
  taxDetailsList :any = [];
  vatDetailsList :any = [];
  addOnDetailsList :any = [];
  invoiceData:any=[];
  statusMap:any;
  obj:any;
  grandTotalTax:any;
  grandTotalVat:any;
  grandTotalAddOn:any;
  showTaxDetails :boolean;
  showVatDetails :boolean;
  showAddOnDetails :boolean;
  showSearchForm : boolean =false;
  result:any;
  resd:any;
  invoiceDetailsTable:any =[];
  invoiceDetailsData:any=[];
  carrierArray :any;
  chargeCodeList: ChargeCode[];
  categoryId: any;
  showOnEvaluate:Boolean;
  categoryList: any;
  chargeCategoryList: any;
  categoryCodeObject: ChargeCategory;
  invoiceDetailsDT:boolean;
  submitted : boolean;
  page:any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  bsValue: Date = new Date(2017, 7);
  minMode: BsDatepickerViewMode = 'month';
  bsConfig: Partial<BsDatepickerConfig>;
  currentSort:any = [{ prop: "", dir: 'asc'}];
  lineItemId:any;
  statusLov : any;
  customerArray : any;
  supplierArray : any;
  supplierCode : string;
  invoiceCaptureScreenConstants = InvoiceCaptureScreenConstants;
  invoiceDetailsList:any = [];
  lineItemList:any =[];
  success: any = {
    isSuccess: false,
    successMessage: ''
  };
  @ViewChild('sortTable') sortTable: DatatableComponent;

  STATUS_EVALUATED = "EV";
  selectedNoOfInvoices : number;
  selectedInvoiceNumber : string = "";
  getInvoiceSummaryActiveRow = (row) => { return { 'selelcted': row.noOfInvoices  == this.selectedNoOfInvoices }}
  getInvoiceDetailsActiveRow = (row) => { return { 'selelcted': row.invoiceNumber  == this.selectedInvoiceNumber }}
  constructor(private chargeCode: ChargeCodeService,private chargeCodeService: ChargeCodeService, private chargeCategoryService: ChargeCategoryService, private messageBoxService: MessageBoxService,private commonService: CommonService, private miscBillingInvoiceEvaluationService:MiscBillingInvoiceEvaluationService,public lov:LovService, private formBuilder: FormBuilder,private carrierService: CarrierMasterService,
  private http: HttpClient, private paginateService: PaginationService,private invoiceCaptureHttpService:InvoiceCaptureHttpService, private router : Router,) { }

  ngOnInit() {
    // this.toggleSearch =true;
    this.toggleSearchSection = true;
    this.searchForm = this.formBuilder.group({
      status:['ALL',[Validators.required]],
      billingPeriodMonth: ['',[Validators.required]],
      billingPeriod: ['',[Validators.required]],
      billingPeriodFromMonth: ['',[Validators.required]],
      billingPeriodFrom: ['',[Validators.required]],
      billingPeriodToMonth: ['',[Validators.required]],
      billingPeriodTo: ['',[Validators.required]],
      supplierType: ['',[Validators.required]],
      supplierCode: ['',[]],
      supplierName: [''],
      billingType: [''],
      chargeCategoryCode: [''],
      invoiceNumber: [''],
    });

    this.bsConfig = Object.assign({}, {
      minMode : this.minMode,
      dateInputFormat : DateConstant.MONTHYEAR
    });
    this.searchForm.controls['supplierName'].disable();
    this.onLoadDefaultValue();
    this.lov.initLovDDS('misc_billing');
    
    this.getAllCarriers();
    this.getAllCustomers();
    this.getChargeCategoryList();
    
  }
  getLovforStatus(){
    return this.lov.getData('status','misc_billing').filter(lov => lov.value == 'ALL' || lov.value == 'OP' || lov.value == 'EV' || lov.value == 'NE' || lov.value == 'CO');
  }

  toggleAdvanceSearch() {
    this.advanceSearch = !this.advanceSearch;
  }

  onLoadDefaultValue(){
    this.searchForm.patchValue({ 
      billingType: 'A',
      status : 'ALL',
      supplierType : 'C'
    });
    this.renderDT=false;
    this.invoiceDetails=false;
    this.showInvoiceLineItem=false;
  }
  getAllCarriers() :void {
		this.carrierService.getAllCarrierList().subscribe((res: any) => {
      this.carrierArray = res;
      this.supplierArray = res;
      this.supplierCode = this.invoiceCaptureScreenConstants.CARRIER_CODE;
      this.onCarrierCodeChangeInvoiceLevel(this.searchForm);
		});
  }
  getAllCustomers(){
  const data = {
    customerType : this.invoiceCaptureScreenConstants.SUPPLIER,
  }
  this.invoiceCaptureHttpService.getAllCustomerList(data).subscribe((res: any) => {
    this.customerArray = res;
  });
  }

  onCarrierCodeChangeInvoiceLevel(form,event?){
    if(form.controls['supplierType'].value == this.invoiceCaptureScreenConstants.DEFAULT_SUPPLIER_TYPE){
      if(!_.isEmpty(event)){
        form.controls['supplierName'].setValue(event.carrierName1);
      }
    } else {
      if(!_.isEmpty(event)){
        form.controls['supplierName'].setValue(event.customerName);
      }
    }
  }

  onSupplierTypeChange(supplierType){
    if(supplierType.fieldValue != this.invoiceCaptureScreenConstants.DEFAULT_SUPPLIER_TYPE){
      this.supplierArray = this.customerArray;
      this.supplierCode = this.invoiceCaptureScreenConstants.CUSTOMER_CODE;
      this.searchForm.controls['supplierCode'].setValue('');
      this.searchForm.controls['supplierName'].setValue('');
    } else{
      this.supplierArray = this.carrierArray;
      this.supplierCode = this.invoiceCaptureScreenConstants.CARRIER_CODE;
      this.searchForm.controls['supplierCode'].setValue('');
      this.searchForm.controls['supplierName'].setValue('');
    }
  }

  onCarrierCodeClear(form){
    form.controls['supplierName'].setValue('');;
  }

  toggleSearchIcon(){
  this.toggleSearchSection = !this.toggleSearchSection;
  }
  get f() {
    return this.searchForm;
  }
  onBillingPeriodAsOnChange(date:any){
    if(date == null || date == undefined) {
       this.f.controls.billingPeriodFromMonth.enable();
       this.f.controls.billingPeriodToMonth.enable();
       this.f.controls.billingPeriodTo.enable();
       this.f.controls.billingPeriodFrom.enable();
   }else{
       this.f.controls.billingPeriodFromMonth.disable();
       this.f.controls.billingPeriodToMonth.disable();
       this.f.controls.billingPeriodTo.disable();
       this.f.controls.billingPeriodFrom.disable(); 
       this.f.controls.billingPeriodFrom.reset();
       this.f.controls.billingPeriodTo.reset();
     }
   }

   onBillingPeriodToFrom(periodfrom:any){
    if(periodfrom == null || periodfrom == undefined) {
      this.f.controls.billingPeriod.enable();
      this.f.controls.billingPeriodMonth.enable();
    }else{
      this.f.controls.billingPeriod.disable();
      this.f.controls.billingPeriodMonth.disable();
      this.f.controls.billingPeriodMonth.reset();

     }
   }
   resetForm(): void {
    this.submitted = false;
    this.f.reset();
    this.onLoadDefaultValue();
   }

  getAllInvoices(){
    this.submitted = true;
    if(this.submitted && !this.f.valid){
      return ;
    }else{
      this.renderDT=false;
      this.invoiceDetails=false;
      this.showInvoiceLineItem=false;
      this.miscBillingInvoiceEvaluationService.searchformCode(this.searchForm.value).subscribe((response:any)  => { 
      this.renderDT = true;
      this.toggleSearchSection = false;
      this.invoiceSearchList = response;
    })
    }
  }

showinvoiceDetails(row : any){
  this.selectedNoOfInvoices = row.noOfInvoices;
  this.invoiceDetails = false;
  this.showInvoiceLineItem = false;
 let data = {
    invoiceList:  row.invoiceList
 };
 this.miscBillingInvoiceEvaluationService.getInvoiceDetails(data).subscribe((response:any) => {
   this.showOnEvaluate = true;

 
response.map(element => {
  element.chargeCategoryName = (this.invoiceSearchList.find(chargeCategory => {
    return element.chargeCategoryCode == chargeCategory.chargeCategoryCode;
  }) || {}).chargeCategoryName;
});
   this.invoiceDetails = true;
   this.invoiceDetailsTable = response;
})
}

goToInvoiceCapture(batchNumber){
  this.router.navigate(["/misc-billing/invoice-capture",{batchNumber : batchNumber, showSearchForm:this.showSearchForm}]);
}

showDetails(row:any){
  this.selectedInvoiceNumber = row.invoiceNumber;
  this.showInvoiceLineItem = false;
  let data = {
    invoiceUrn:  row.invoiceUrn
 };
  this.miscBillingInvoiceEvaluationService.getInvoiceDetailsOnInvoiceNo(data).subscribe((response:any) => {
    this.showInvoiceLineItem = true
    this.result = response.filter(startDateData => {
      startDateData.startDate = this.commonService.covertDate(startDateData.startDate);
      return startDateData.startDate
    });
    this.result = response.filter(endDateData => {
      endDateData.endDate = this.commonService.covertDate(endDateData.endDate);
      return endDateData.endDate
    });
    this.getChargeCodeName(row.chargeCategoryCode);
    this.invoiceDetailsData = this.result;
  
  })
  
}
getChargeCategoryList() {
  this.chargeCategoryService.getChargeCategory().subscribe((res:ChargeCategory[]) => {
    this.categoryList = res;
  })
}
getChargeCodeName(chargeCategoryCode){
  this.chargeCode.getChargeCodeListData(chargeCategoryCode).subscribe((res: ChargeCode[]) => {
    if (res != null) {
      this.chargeCodeList = res;
      this.result.map(response => {
        response = this.setChargeCodeName(response);
      });
  
    }
   });
}

setChargeCodeName(data){
  data.chargeCodeName = this.chargeCodeList.find(chargeCodes => chargeCodes.chargeCode === data.chargeCode).chargeCodeName;
  return data;
}

selectedRow(rowData,level){
  this.level = level;
  this.selectedRowData = rowData;
}
showAlertMessage(Obj) {
  this.success = Obj;
  this.closeAlertValidation();
}
closeAlertValidation() {
  let tempThis = this;
  window.setTimeout(()=> {
    tempThis.success = { isSuccess: false, successMessage: '' };
  }, AlertMessageConstants.CLOSE_ALERT_TIME);
}
updateDataTable(data,type){
  if(type == 'add') this.invoiceDetailsData.unshift(data);	
  else{
    const ind = this.invoiceDetailsData.findIndex((item) => { return data.invLineItemId == item.invLineItemId;});
  if(ind == -1) return false;if(type =='update')  this.invoiceDetailsData[ind] = data;else if(type == 'remove') this.invoiceDetailsData.splice(ind, 1);
  }
  this.invoiceDetailsData = [...this.invoiceDetailsData];
}
selectedRowDataLineItems(data) {
  this.setChargeCodeName(data);
  this.updateDataTable(data,'update');
}
selectedRowDataLineItem1(lineItemId){
this.lineItemId = lineItemId.data;
this.level = lineItemId.level;
}


confirmEvaluation(){
 let data = {
   status : this.STATUS_EVALUATED,
   invoices : this.invoiceDetailsTable.map(invoicedetails =>{
     return {
       status : '',
       invoiceno : invoicedetails.invoiceUrn
     }
   })
 }
 let lineItemData = {
  status : this.STATUS_EVALUATED,
  invoices : this.invoiceDetailsData.map(invoicedetails =>{
    return {
      status : '',
      invoiceno : invoicedetails.invLineItemId
    }
  })
}
 if(this.level == 'invoiceLevel'){
   this.miscBillingInvoiceEvaluationService.evaluateInvoice(data).subscribe((response:any) => {
   this.invoiceDetailsTable.map(processdata=>{
      if(response.status == this.STATUS_EVALUATED && processdata.invoiceUrn == this.selectedRowData){
        return processdata.invoiceStatus = this.STATUS_CONFIRMED
      }else{
       return  processdata.invoiceStatus
      }
    })
  })
  this.miscBillingInvoiceEvaluationService.createRejectedInvoice().subscribe((response:any) => {});

}else if(this.level == 'lineItem'){
  this.miscBillingInvoiceEvaluationService.evaluateInvoiceLineItem(lineItemData).subscribe((response:any) => {   
    this.invoiceDetailsData.map(processdata=>{
      if(response.status == this.STATUS_EVALUATED && processdata.invLineItemId == this.lineItemId){
        return processdata.processStatus = this.STATUS_CONFIRMED
        } else{
          return  processdata.processStatus
         } 
    })
           
  })
  this.miscBillingInvoiceEvaluationService.createRejectedInvoice().subscribe((response:any) => {});
}
}

getTaxDetails(row:any){

this.taxDetailsList = row.miscBillingTaxDetails.filter(taxDetails => {
  return taxDetails.taxType.toUpperCase() == "TAX";
});
this.grandTotalTax = this.taxDetailsList.reduce((s, f) => s + f.taxAmount, 0);
this.showTaxDetails = true;
}
getVatDetails(row:any){
  this.vatDetailsList = row.miscBillingTaxDetails.filter(vatDetails => {
    return vatDetails.taxType.toUpperCase() == "VAT";
  });
  this.grandTotalVat = this.vatDetailsList.reduce((s, f) => s + f.taxAmount, 0);
  this.showVatDetails = true;
  } 


  getAddOnDetails(row:any){
    this.addOnDetailsList = row.miscBillingAddOnChargeDtl;
    this.grandTotalAddOn = this.addOnDetailsList.reduce((s, f) => s + f.addOnChargeAmount, 0);
    this.showAddOnDetails = true;


}



// show invoice smummary
// getInvoiceSummary(row : any){
//   let data = {
//      invoiceList:  row.invoiceList
//   };
//   this.miscBillingInvoiceEvaluationService.getInvoiceDetails(data).subscribe((response:any) => {
//     // this.invoiceDetailsList = response;
//     // used this slist for invoice details list 
//     this.invoiceDetailsTable = response;
//     response.map(element => {
//       element.chargeCategoryName = (this.invoiceSearchList.find(chargeCategory => {
//         return element.chargeCategoryCode == chargeCategory.chargeCategoryCode;
//       }) || {}).chargeCategoryName;
//     });
//   })
  
//   this.invoiceDetailsTable.forEach(element => {
//     this.lineItemList.push(element['miscBillingInvLineitem']);
//   });
//   this.renderDT = true;
//   this.invoiceDetails = true;
//    this.showInvoiceLineItem=false;
//   this.showOnEvaluate = true;
//  }
// // display invoice details list
//  showInvoiceDetails(){
//    this.invoiceDetailsList;
//    this.renderDT = true;
//    this.invoiceDetails = true;
//    this.showInvoiceLineItem=false;
//  }
// // show line item 
//  showLineItems(row){
//    this.lineItemList;
//    this.showInvoiceLineItem=true;
//    this.invoiceDetails = true;
//    this.renderDT = true;
//    this.getChargeCodeName(row.chargeCategoryCode);
//    this.invoiceDetailsData = this.lineItemList;
//  }
}
