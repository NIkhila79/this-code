import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MiscBillingInvoiceEvaluationRoutingModule } from './misc-billing-invoice-evaluation-routing.module';
import { MiscBillingInvoiceEvaluationComponent } from './misc-billing-invoice-evaluation.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';
import { InvoiceEvaluationLineItemComponent } from './invoice-evaluation-line-item/invoice-evaluation-line-item.component';
import { InvoiceCaptureModule } from '../invoice-capture/invoice-capture.module';

@NgModule({
  imports: [
    CommonModule,
    MiscBillingInvoiceEvaluationRoutingModule,
    ReactiveFormsModule,
    SharedModule,
    CoreDataModule,
    InvoiceCaptureModule
    
  ],
  declarations: [MiscBillingInvoiceEvaluationComponent, InvoiceEvaluationLineItemComponent]
})
export class MiscBillingInvoiceEvaluationModule { }
